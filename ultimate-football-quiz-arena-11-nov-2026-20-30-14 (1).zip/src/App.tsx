import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  Trophy, 
  Brain, 
  Volume2, 
  VolumeX, 
  HelpCircle, 
  Shield, 
  Flame, 
  ChevronRight, 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  Share2, 
  RotateCcw, 
  Home, 
  Clock, 
  Award,
  Zap,
  Check,
  AlertTriangle,
  Send
} from 'lucide-react';

import { DifficultyTier, Question, IQResult, AnswerRecord } from './types';
import { QUESTION_DATABASE, SUBCATEGORIES, TIER_SETTINGS, FOOTBALL_IQ_QUESTIONS } from './data/questions';
import { fuzzyMatch, strictMatch } from './utils/fuzzy';
import { soundManager } from './utils/audio';
import { LeaderboardAd728x90, BannerAd300x250, NativeAdContainer } from './components/AdBanners';
import { FAQModal, PrivacyModal, TermsModal, ContactModal, ChallengeModal } from './components/Modals';
import { CookieBanner } from './components/CookieBanner';

export default function App() {
  // App Navigation & Views
  const [currentView, setCurrentView] = useState<'menu' | 'subcat' | 'quiz' | 'summary'>('menu');
  const [selectedTier, setSelectedTier] = useState<DifficultyTier>('easy');
  const [activeSubcatTitle, setActiveSubcatTitle] = useState<string>('');
  const [isIQTestMode, setIsIQTestMode] = useState<boolean>(false);

  // Active Quiz State
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(20);
  const [totalTimeForQ, setTotalTimeForQ] = useState<number>(20);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [maxStreak, setMaxStreak] = useState<number>(0);
  const [userTypingAnswer, setUserTypingAnswer] = useState<string>('');
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [hasAnswered, setHasAnswered] = useState<boolean>(false);
  const [answerHistory, setAnswerHistory] = useState<AnswerRecord[]>([]);

  // Persistent User Records
  const [bestScore, setBestScore] = useState<number>(0);
  const [bestIQ, setBestIQ] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Summary & IQ Calculations
  const [iqResult, setIqResult] = useState<IQResult | null>(null);
  const [animatedScore, setAnimatedScore] = useState<number>(0);
  const [animatedIQ, setAnimatedIQ] = useState<number>(0);

  // Modals
  const [isFAQOpen, setIsFAQOpen] = useState<boolean>(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState<boolean>(false);
  const [isTermsOpen, setIsTermsOpen] = useState<boolean>(false);
  const [isContactOpen, setIsContactOpen] = useState<boolean>(false);
  const [isChallengeOpen, setIsChallengeOpen] = useState<boolean>(false);

  // Refs
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const typingInputRef = useRef<HTMLInputElement | null>(null);

  // Initialize stored data
  useEffect(() => {
    const savedScore = localStorage.getItem('football_quiz_best_score');
    if (savedScore) setBestScore(parseInt(savedScore, 10));

    const savedIQ = localStorage.getItem('football_quiz_iq');
    if (savedIQ) setBestIQ(parseInt(savedIQ, 10));

    setIsMuted(soundManager.isMuted);
  }, []);

  // Timer interval hook
  useEffect(() => {
    if (currentView !== 'quiz' || hasAnswered) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          handleTimeExpired();
          return 0;
        }
        if (prev <= 4) {
          soundManager.playTick();
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentView, currentQIndex, hasAnswered]);

  // Focus input on typing questions
  useEffect(() => {
    if (currentView === 'quiz' && !hasAnswered) {
      const q = questions[currentQIndex];
      if (q && q.mode === 'typing') {
        setTimeout(() => typingInputRef.current?.focus(), 50);
      }
    }
  }, [currentView, currentQIndex, hasAnswered, questions]);

  // Start Standard Subcategory Quiz
  const startSubcategoryQuiz = (tier: DifficultyTier, subcatId: string, title: string) => {
    soundManager.playClick();
    setSelectedTier(tier);
    setActiveSubcatTitle(title);
    setIsIQTestMode(false);

    const subcat = SUBCATEGORIES.find((s) => s.id === subcatId);
    const qList = subcat ? [...subcat.questions] : [];
    launchQuizSession(qList, tier);
  };

  // Start Certified Football IQ Assessment
  const startFootballIQTest = () => {
    soundManager.playClick();
    setIsIQTestMode(true);
    setActiveSubcatTitle('Official Football IQ Assessment');
    launchQuizSession(FOOTBALL_IQ_QUESTIONS, 'medium');
  };

  const launchQuizSession = (qList: Question[], fallbackTier: DifficultyTier) => {
    const shuffled = [...qList].sort(() => Math.random() - 0.5);
    setQuestions(shuffled);
    setCurrentQIndex(0);
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    setAnswerHistory([]);
    setHasAnswered(false);
    setSelectedOption(null);
    setUserTypingAnswer('');

    const firstQ = shuffled[0];
    const initialTier = firstQ ? firstQ.difficulty : fallbackTier;
    const duration = TIER_SETTINGS[initialTier].timer;
    setTimeLeft(duration);
    setTotalTimeForQ(duration);
    setCurrentView('quiz');
  };

  // Evaluation & Scoring Logic
  const handleAnswerSubmit = (givenAnswer: string) => {
    if (hasAnswered) return;
    setHasAnswered(true);

    const currentQ = questions[currentQIndex];
    if (!currentQ) return;

    let isCorrect = false;
    if (currentQ.mode === 'mcq') {
      setSelectedOption(givenAnswer);
      isCorrect = givenAnswer.toLowerCase() === currentQ.correctAnswer.toLowerCase();
    } else {
      const targets = currentQ.acceptedAnswers || [currentQ.correctAnswer];
      if (currentQ.difficulty === 'impossible') {
        isCorrect = strictMatch(givenAnswer, targets);
      } else {
        isCorrect = fuzzyMatch(givenAnswer, targets, 2);
      }
    }

    let pointsAdded = 0;
    if (isCorrect) {
      soundManager.playCorrect();
      const newStreak = streak + 1;
      setStreak(newStreak);
      if (newStreak > maxStreak) setMaxStreak(newStreak);

      const multiplier = Math.min(3.0, 1.0 + (newStreak - 1) * 0.25);
      const tierConfig = TIER_SETTINGS[currentQ.difficulty];
      const speedRatio = Math.max(0.2, timeLeft / totalTimeForQ);
      pointsAdded = Math.round(tierConfig.basePoints * (1 + speedRatio) * multiplier);

      setScore((prev) => prev + pointsAdded);
    } else {
      soundManager.playIncorrect();
      setStreak(0);
    }

    setAnswerHistory((prev) => [
      ...prev,
      {
        questionId: currentQ.id,
        questionText: currentQ.text,
        userAnswer: givenAnswer,
        correctAnswer: currentQ.correctAnswer,
        isCorrect,
        pointsEarned: pointsAdded,
        timeSpent: totalTimeForQ - timeLeft
      }
    ]);
  };

  const handleTimeExpired = () => {
    if (hasAnswered) return;
    setHasAnswered(true);
    soundManager.playIncorrect();
    setStreak(0);

    const currentQ = questions[currentQIndex];
    if (currentQ) {
      setAnswerHistory((prev) => [
        ...prev,
        {
          questionId: currentQ.id,
          questionText: currentQ.text,
          userAnswer: '[TIME EXPIRED]',
          correctAnswer: currentQ.correctAnswer,
          isCorrect: false,
          pointsEarned: 0,
          timeSpent: totalTimeForQ
        }
      ]);
    }
  };

  const advanceNextQuestion = () => {
    soundManager.playClick();
    if (currentQIndex + 1 < questions.length) {
      const nextIdx = currentQIndex + 1;
      setCurrentQIndex(nextIdx);
      setHasAnswered(false);
      setSelectedOption(null);
      setUserTypingAnswer('');

      const nextQ = questions[nextIdx];
      const duration = TIER_SETTINGS[nextQ.difficulty].timer;
      setTimeLeft(duration);
      setTotalTimeForQ(duration);
    } else {
      finalizeQuizResults();
    }
  };

  // Finalize Quiz & Calculate IQ / Brain Age
  const finalizeQuizResults = () => {
    setCurrentView('summary');

    // Update Personal Best
    if (score > bestScore) {
      setBestScore(score);
      localStorage.setItem('football_quiz_best_score', score.toString());
    }

    if (isIQTestMode) {
      // Calibrate IQ Score (Gaussian 70–160 Scale)
      const correctRatio = answerHistory.filter((a) => a.isCorrect).length / Math.max(1, questions.length);
      const rawIQ = Math.round(70 + correctRatio * 85 + (score > 3500 ? 5 : 0));
      const finalIQ = Math.min(160, Math.max(70, rawIQ));

      const isBad = finalIQ < 100;
      let calculatedBrainAge = 25;
      let archetype = 'Academy Prospect';
      let verdict = 'Respectable football fan with room to master European tactical geometry.';

      if (finalIQ >= 145) {
        calculatedBrainAge = 58;
        archetype = 'Tactical Grandmaster';
        verdict = 'Visionary football intellect. You understand the spatial geometry of Sacchi, Guardiola, and Cruyff.';
      } else if (finalIQ >= 130) {
        calculatedBrainAge = 45;
        archetype = 'European Tactician';
        verdict = 'Elite football mind with encyclopedic recall of knockout history and continental records.';
      } else if (finalIQ >= 115) {
        calculatedBrainAge = 34;
        archetype = 'Pro League Veteran';
        verdict = 'Sharp tactical awareness and reliable recall of classic finals.';
      } else if (finalIQ >= 100) {
        calculatedBrainAge = 22;
        archetype = 'Solid Matchgoing Fan';
        verdict = 'Good mainstream football knowledge, occasionally caught out by obscure archival records.';
      } else {
        calculatedBrainAge = 7;
        archetype = 'Armchair Casual';
        verdict = 'You should not play football anymore! Hang up your boots, donate your shin pads, and stick to watching from the sofa with a warm tea.';
      }

      const calculatedSmartness = Math.round(Math.min(99.8, Math.max(15, (finalIQ - 70) / 0.9)));

      const iqData: IQResult = {
        iqScore: finalIQ,
        brainAge: calculatedBrainAge,
        smartness: calculatedSmartness,
        rankTitle: archetype,
        isBadIQ: isBad,
        verdict
      };

      setIqResult(iqData);
      setBestIQ(finalIQ);
      localStorage.setItem('football_quiz_iq', finalIQ.toString());

      if (!isBad) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    } else {
      setIqResult(null);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
    }

    // GSAP / Smooth Count Up
    animateCountUp(score, isIQTestMode ? Math.min(160, Math.max(70, Math.round(70 + (answerHistory.filter((a) => a.isCorrect).length / Math.max(1, questions.length)) * 85))) : 0);
  };

  const animateCountUp = (targetScore: number, targetIQ: number) => {
    let startScore = 0;
    let startIQ = 0;
    const duration = 1200;
    const steps = 30;
    const intervalTime = duration / steps;

    const timer = setInterval(() => {
      startScore += Math.ceil(targetScore / steps);
      startIQ += Math.ceil(targetIQ / steps);

      if (startScore >= targetScore) {
        setAnimatedScore(targetScore);
        setAnimatedIQ(targetIQ);
        clearInterval(timer);
      } else {
        setAnimatedScore(startScore);
        setAnimatedIQ(startIQ);
      }
    }, intervalTime);
  };

  const handleResetData = () => {
    if (window.confirm('Are you sure you want to erase your saved High Score and Football IQ record?')) {
      localStorage.removeItem('football_quiz_best_score');
      localStorage.removeItem('football_quiz_iq');
      setBestScore(0);
      setBestIQ(null);
      setIsPrivacyOpen(false);
      alert('Local arena records successfully reset.');
    }
  };

  const toggleSound = () => {
    const muted = soundManager.toggleMute();
    setIsMuted(muted);
  };

  const currentQ = questions[currentQIndex];
  const timerPercent = (timeLeft / totalTimeForQ) * 100;
  const strokeColor = timeLeft <= 3 ? '#ff3366' : timeLeft <= 7 ? '#ffb700' : '#00ff88';

  return (
    <div className="min-h-screen flex flex-col justify-between relative pitch-pattern">
      {/* Dynamic Background Dark Overlays */}
      <div className="fixed inset-0 bg-[#07100c]/90 backdrop-blur-[3px] pointer-events-none -z-10" />

      {/* Header Navigation */}
      <header className="max-w-5xl mx-auto w-full px-4 pt-4 pb-2 flex flex-wrap items-center justify-between gap-3">
        <div 
          onClick={() => setCurrentView('menu')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-10 h-10 rounded-full bg-[#00ff88] flex items-center justify-center text-[#07100c] shadow-[0_0_15px_rgba(0,255,136,0.5)] group-hover:scale-105 transition-transform">
            ⚽
          </div>
          <div>
            <h1 className="font-heading text-xl sm:text-2xl font-black text-white tracking-wider">
              FOOTBALL <span className="text-[#00ff88]">ARENA</span>
            </h1>
            <p className="text-[10px] text-slate-400 font-medium tracking-widest uppercase">
              Tactical &amp; Heritage Benchmark
            </p>
          </div>
        </div>

        {/* Header Action Badges & Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsFAQOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:border-[#00ff88] text-xs font-bold text-slate-200 hover:text-white transition-all"
          >
            <HelpCircle className="w-3.5 h-3.5 text-[#00ff88]" />
            <span>FAQ</span>
          </button>

          <button
            onClick={() => setIsPrivacyOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:border-[#38bdf8] text-xs font-bold text-slate-200 hover:text-white transition-all"
          >
            <Shield className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>Privacy</span>
          </button>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#c084fc]/15 border border-[#c084fc]/40 text-xs font-extrabold text-[#d8b4fe]">
            <Brain className="w-3.5 h-3.5" />
            <span>{bestIQ ? `IQ: ${bestIQ}` : 'IQ: --'}</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-slate-200">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>{bestScore.toLocaleString()} PTS</span>
          </div>

          <button
            onClick={toggleSound}
            aria-label="Toggle Sound Effects"
            className="w-8 h-8 rounded-full bg-white/5 border border-white/10 hover:border-[#00ff88] flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-[#00ff88]" />}
          </button>
        </div>
      </header>

      {/* Ad Slot 3: Leaderboard Banner Ad (728x90) */}
      <LeaderboardAd728x90 />

      {/* Main Content Card Container */}
      <main className="max-w-4xl mx-auto w-full px-4 py-2 flex-1 flex flex-col justify-center">
        <div className="bg-[#0b1a13]/85 border border-[#00ff88]/25 rounded-2xl p-4 sm:p-7 shadow-[0_16px_40px_rgba(0,0,0,0.7)] backdrop-blur-xl relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#00ff88] to-transparent" />

          {/* ================= VIEW 1: MAIN MENU ================= */}
          {currentView === 'menu' && (
            <div className="space-y-6">
              {/* Hero Conversion Hook with Silky-Smooth Hover (Zero Black Flicker!) */}
              <div className="bg-radial-[at_50%_0%] from-[#00ff88]/15 via-[#07140e]/95 to-[#050e0a]/98 border border-[#00ff88]/30 rounded-2xl p-6 text-center space-y-3 shadow-xl">
                <span className="inline-block bg-[#00ff88]/20 border border-[#00ff88]/40 text-[#00ff88] text-[10px] sm:text-xs font-extrabold uppercase px-3 py-1 rounded-full tracking-wider">
                  ⚽ OFFICIAL FOOTBALL IQ ASSESSMENT • CERTIFIED TACTICAL SCALE
                </span>
                <h2 className="font-heading text-2xl sm:text-4xl font-black text-white leading-tight">
                  ARE YOU A <span className="text-[#00ff88]">REAL FOOTBALL FAN</span> — OR JUST AN ARMCHAIR CASUAL?
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto leading-relaxed">
                  Put your tactical memory, historic recall, and football intellect to the ultimate test. Discover your certified <strong>Football IQ (70 – 160)</strong>, reveal your true <strong>Tactical Brain Age</strong>, or receive the verdict: <em>You should not play football anymore</em>.
                </p>

                {/* Main Hero CTA Button with Smooth Brightness Hover */}
                <div className="pt-2">
                  <button
                    onClick={startFootballIQTest}
                    className="inline-flex items-center gap-2 bg-[#00ff88] text-[#07100c] font-heading font-black text-base sm:text-xl uppercase px-8 py-3.5 rounded-xl shadow-[0_0_30px_rgba(0,255,136,0.5)] hover:brightness-110 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <Zap className="w-5 h-5 fill-current" />
                    <span>TAKE THE TEST NOW — PROVE YOUR FOOTBALL IQ</span>
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-4 text-[11px] text-slate-400 font-semibold pt-1">
                  <span>⏱️ Speed &amp; Accuracy Weighted</span>
                  <span>•</span>
                  <span>🧠 Instant Brain Age &amp; Smartness Score</span>
                  <span>•</span>
                  <span>🛡️ 100% Free &amp; No Sign-Up</span>
                </div>
              </div>

              {/* Mode Selection Grid */}
              <div className="text-center pt-2">
                <span className="text-xs uppercase font-extrabold tracking-widest text-[#00ff88]">Interactive Game Modes</span>
                <h3 className="font-heading text-2xl font-black text-white uppercase mt-0.5">
                  Select Your <em>Difficulty Tier</em>
                </h3>
              </div>

              {/* 5 Difficulty Tiers Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {(Object.keys(TIER_SETTINGS) as DifficultyTier[]).map((tierKey) => {
                  const tier = TIER_SETTINGS[tierKey];
                  return (
                    <div
                      key={tierKey}
                      onClick={() => {
                        setSelectedTier(tierKey);
                        setCurrentView('subcat');
                        soundManager.playClick();
                      }}
                      className="bg-[#0f241a]/60 hover:bg-[#123021]/85 border border-white/10 hover:border-[#00ff88] rounded-xl p-4 cursor-pointer transition-all hover:-translate-y-1 hover:shadow-[0_8px_24px_rgba(0,0,0,0.5)] flex flex-col justify-between"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span 
                          className="font-heading font-black text-sm uppercase"
                          style={{ color: tier.color }}
                        >
                          {tier.name} Tier
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/10 text-slate-300">
                          {tier.timer}s Timer
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mb-3">
                        {tier.mode === 'mcq' ? 'Multiple choice questions with rapid streak multipliers.' : 'Direct text typing under strict linguistic verification.'}
                      </p>
                      <div className="flex items-center justify-between text-[11px] font-bold pt-2 border-t border-white/5">
                        <span className="text-slate-400">{tier.basePoints} Base PTS</span>
                        <span className="text-[#00ff88] flex items-center gap-1">
                          Select Topic ➔
                        </span>
                      </div>
                    </div>
                  );
                })}

                {/* Dedicated Football IQ Card in Grid */}
                <div
                  onClick={startFootballIQTest}
                  className="bg-gradient-to-br from-[#1e1236]/90 to-[#0d241b]/90 border-2 border-[#c084fc]/50 hover:border-[#00ff88] rounded-xl p-4 cursor-pointer transition-all hover:-translate-y-1 shadow-[0_0_20px_rgba(192,132,252,0.2)] flex flex-col justify-between sm:col-span-2 lg:col-span-1"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-heading font-black text-sm uppercase text-[#c084fc]">
                      🧠 Certified Football IQ
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#c084fc]/20 text-[#d8b4fe]">
                      15 Qs
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mb-3">
                    Calculated 70–160 rating with true Football Brain Age assessment across all difficulty tiers.
                  </p>
                  <div className="flex items-center justify-between text-[11px] font-bold pt-2 border-t border-white/5">
                    <span className="text-[#d8b4fe]">Official Rubric</span>
                    <span className="text-[#00ff88] flex items-center gap-1">
                      Start Test ➔
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= VIEW 2: SUBCATEGORY SELECTION ================= */}
          {currentView === 'subcat' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <button
                  onClick={() => setCurrentView('menu')}
                  className="flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-[#00ff88] transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Main Menu</span>
                </button>
                <span className="text-xs font-heading font-bold uppercase text-[#00ff88] tracking-wider">
                  {TIER_SETTINGS[selectedTier].name} Sub-Categories
                </span>
              </div>

              <div className="text-center">
                <h3 className="font-heading text-xl sm:text-2xl font-black text-white uppercase">
                  Select Your Specialized Topic
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Each topic tests distinct eras, tactical patterns, and tournament records.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {SUBCATEGORIES.filter((s) => s.tier === selectedTier).map((sub) => (
                  <div
                    key={sub.id}
                    onClick={() => startSubcategoryQuiz(selectedTier, sub.id, sub.title)}
                    className="bg-[#0e2219]/70 hover:bg-[#123223]/90 border border-white/10 hover:border-[#00ff88] rounded-xl p-4 cursor-pointer transition-all hover:-translate-y-1 shadow-lg flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2.5 mb-1.5">
                        <span className="text-2xl">{sub.icon}</span>
                        <h4 className="font-heading font-bold text-white text-base">{sub.title}</h4>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">{sub.desc}</p>
                    </div>
                    <div className="flex items-center justify-between text-xs font-bold pt-3 mt-3 border-t border-white/5">
                      <span className="text-slate-400">{sub.questions.length} Questions</span>
                      <span className="text-[#00ff88] flex items-center gap-1">
                        Start Quiz ➔
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= VIEW 3: ACTIVE QUIZ ================= */}
          {currentView === 'quiz' && currentQ && (
            <div className="space-y-4">
              {/* Quiz HUD */}
              <div className="flex items-center justify-between border-b border-white/10 pb-3 gap-2">
                <div className="flex items-center gap-2">
                  <span className="bg-white/10 text-slate-300 text-[11px] font-bold px-2.5 py-1 rounded-md uppercase">
                    Q {currentQIndex + 1} / {questions.length}
                  </span>
                  <span className="text-xs font-heading font-bold text-[#00ff88] uppercase hidden sm:inline">
                    {currentQ.category}
                  </span>
                </div>

                {/* Circular Animated Countdown Timer */}
                <div className="flex items-center gap-3">
                  {streak > 1 && (
                    <div className="flex items-center gap-1 text-xs font-extrabold text-amber-400 bg-amber-400/15 px-2 py-0.5 rounded-full border border-amber-400/30 animate-pulse">
                      <Flame className="w-3.5 h-3.5" />
                      <span>{streak}x STREAK</span>
                    </div>
                  )}

                  <div className="relative w-12 h-12 flex items-center justify-center">
                    <svg className="w-full h-full -rotate-90">
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        className="stroke-white/10"
                        strokeWidth="3.5"
                        fill="none"
                      />
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        stroke={strokeColor}
                        strokeWidth="3.5"
                        strokeDasharray={125.6}
                        strokeDashoffset={125.6 - (125.6 * timerPercent) / 100}
                        strokeLinecap="round"
                        fill="none"
                        className="transition-all duration-1000 ease-linear"
                      />
                    </svg>
                    <span 
                      className="absolute font-heading font-extrabold text-xs"
                      style={{ color: strokeColor }}
                    >
                      {timeLeft}s
                    </span>
                  </div>

                  <div className="text-right">
                    <div className="text-[10px] uppercase text-slate-400 font-bold">SCORE</div>
                    <div className="font-heading text-sm font-extrabold text-white">{score} PTS</div>
                  </div>
                </div>
              </div>

              {/* Question Text */}
              <div className="py-2">
                <h3 className="text-base sm:text-xl font-bold text-white leading-relaxed">
                  {currentQ.text}
                </h3>
              </div>

              {/* Options or Direct Typing Input */}
              {currentQ.mode === 'mcq' && currentQ.options ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {currentQ.options.map((opt, idx) => {
                    const isSelected = selectedOption === opt;
                    const isCorrect = opt.toLowerCase() === currentQ.correctAnswer.toLowerCase();
                    let btnStyle = 'bg-[#0e2219]/70 border-white/10 text-white hover:border-[#00ff88] hover:bg-[#123223]/80';

                    if (hasAnswered) {
                      if (isCorrect) {
                        btnStyle = 'bg-[#00ff88]/25 border-[#00ff88] text-white shadow-[0_0_15px_rgba(0,255,136,0.3)]';
                      } else if (isSelected && !isCorrect) {
                        btnStyle = 'bg-red-500/25 border-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.3)]';
                      } else {
                        btnStyle = 'bg-black/30 border-white/5 text-slate-500 opacity-60';
                      }
                    }

                    return (
                      <button
                        key={idx}
                        disabled={hasAnswered}
                        onClick={() => handleAnswerSubmit(opt)}
                        className={`w-full p-3.5 rounded-xl border text-left font-semibold text-xs sm:text-sm transition-all flex items-center gap-3 ${btnStyle}`}
                      >
                        <span className="w-6 h-6 rounded bg-white/10 flex items-center justify-center font-heading font-bold text-xs flex-shrink-0">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="flex-1">{opt}</span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                /* Extreme / Impossible Direct Typing Input */
                <div className="space-y-3 pt-2">
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (userTypingAnswer.trim()) {
                        handleAnswerSubmit(userTypingAnswer.trim());
                      }
                    }}
                    className="flex gap-2"
                  >
                    <input
                      ref={typingInputRef}
                      type="text"
                      disabled={hasAnswered}
                      value={userTypingAnswer}
                      onChange={(e) => setUserTypingAnswer(e.target.value)}
                      placeholder="Type official player surname or full name..."
                      className="flex-1 bg-[#07140e] border border-white/20 focus:border-[#00ff88] rounded-xl px-4 py-3 text-sm text-white outline-none transition-colors"
                    />
                    <button
                      type="submit"
                      disabled={hasAnswered || !userTypingAnswer.trim()}
                      className="bg-[#00ff88] text-[#07100c] font-heading font-extrabold uppercase px-6 rounded-xl hover:bg-white disabled:opacity-50 transition-all text-xs"
                    >
                      Submit
                    </button>
                  </form>
                  <p className="text-[11px] text-slate-400">
                    💡 <em>Linguistic tolerance active: accents (é, ü, ñ) and minor typos up to 2 characters are normalized.</em>
                  </p>
                </div>
              )}

              {/* Instant Feedback Tray & Next Question Button */}
              {hasAnswered && (
                <div className="bg-[#07140e] border border-[#00ff88]/30 rounded-xl p-4 mt-4 animate-in fade-in duration-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {answerHistory[answerHistory.length - 1]?.isCorrect ? (
                        <>
                          <CheckCircle2 className="w-5 h-5 text-[#00ff88]" />
                          <span className="font-heading font-extrabold text-[#00ff88] text-sm uppercase">Correct Answer!</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-5 h-5 text-red-400" />
                          <span className="font-heading font-extrabold text-red-400 text-sm uppercase">Incorrect</span>
                        </>
                      )}
                    </div>
                    {answerHistory[answerHistory.length - 1]?.isCorrect && (
                      <span className="font-heading font-bold text-amber-400 text-xs">
                        +{answerHistory[answerHistory.length - 1].pointsEarned} PTS
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Official Fact:</strong> {currentQ.explanation}
                  </p>

                  <div className="pt-2 text-right">
                    <button
                      onClick={advanceNextQuestion}
                      className="bg-[#00ff88] text-[#07100c] font-heading font-bold text-xs uppercase px-5 py-2.5 rounded-lg hover:bg-white transition-colors"
                    >
                      {currentQIndex + 1 < questions.length ? 'Next Question ➔' : 'Finish Quiz & View Summary ➔'}
                    </button>
                  </div>
                </div>
              )}

              {/* Ad Slot 2: 300x250 Banner Ad placed cleanly below the active question */}
              <BannerAd300x250 className="pt-2" />
            </div>
          )}

          {/* ================= VIEW 4: SUMMARY & FOOTBALL IQ ================= */}
          {currentView === 'summary' && (
            <div className="space-y-6 text-center">
              <div className="text-5xl animate-bounce">🏆</div>

              <div>
                <h3 className="font-heading text-2xl sm:text-3xl font-black text-white uppercase">
                  {isIQTestMode ? 'Certified Assessment Complete' : 'Quiz Challenge Completed!'}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Here is your official tactical and trivia performance breakdown:
                </p>
              </div>

              {/* Score / IQ Highlight Card */}
              {isIQTestMode && iqResult ? (
                <div className="space-y-4">
                  <div className="bg-gradient-to-br from-[#1b102e] to-[#0a1c13] border-2 border-[#c084fc] rounded-2xl p-5 shadow-2xl space-y-3">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#d8b4fe] bg-[#c084fc]/20 px-3 py-1 rounded-full">
                      OFFICIAL FOOTBALL IQ
                    </span>

                    <div className="font-heading text-5xl sm:text-6xl font-black text-white tracking-tight">
                      {animatedIQ} <span className="text-xs sm:text-sm font-bold text-[#00ff88]">IQ</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-center">
                      <div className="bg-black/40 rounded-xl p-2.5 border border-white/5">
                        <div className="text-[10px] text-slate-400 uppercase font-bold">Brain Age</div>
                        <div className="font-heading font-bold text-base text-[#38bdf8]">{iqResult.brainAge} Years</div>
                      </div>
                      <div className="bg-black/40 rounded-xl p-2.5 border border-white/5">
                        <div className="text-[10px] text-slate-400 uppercase font-bold">Smartness</div>
                        <div className="font-heading font-bold text-base text-amber-400">Top {100 - iqResult.smartness}%</div>
                      </div>
                      <div className="bg-black/40 rounded-xl p-2.5 border border-white/5 col-span-2 sm:col-span-1">
                        <div className="text-[10px] text-slate-400 uppercase font-bold">Archetype</div>
                        <div className="font-heading font-bold text-base text-[#00ff88] truncate">{iqResult.rankTitle}</div>
                      </div>
                    </div>
                  </div>

                  {/* Bad IQ Warning Banner */}
                  {iqResult.isBadIQ ? (
                    <div className="bg-red-500/15 border-2 border-red-500/60 rounded-xl p-4 text-left space-y-1.5 shadow-lg">
                      <div className="flex items-center gap-2 text-red-400 font-heading font-black text-sm uppercase">
                        <AlertTriangle className="w-5 h-5 flex-shrink-0" />
                        <span>TACTICAL PERFORMANCE DEFICIT DETECTED</span>
                      </div>
                      <p className="text-xs sm:text-sm text-red-200 font-medium leading-relaxed">
                        <strong>Official Arena Verdict:</strong> {iqResult.verdict}
                      </p>
                    </div>
                  ) : (
                    <div className="bg-[#00ff88]/10 border border-[#00ff88]/40 rounded-xl p-3.5 text-xs text-slate-200">
                      <strong>Tactical Acumen Confirmed:</strong> {iqResult.verdict}
                    </div>
                  )}
                </div>
              ) : (
                /* Standard Quiz Summary */
                <div className="bg-black/40 border border-white/10 rounded-2xl p-5 space-y-3">
                  <div className="font-heading text-4xl sm:text-5xl font-black text-[#00ff88]">
                    {animatedScore.toLocaleString()} <span className="text-xs text-slate-400">PTS</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center pt-2">
                    <div className="bg-white/5 p-2 rounded-lg">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Correct</div>
                      <div className="font-heading font-bold text-sm text-white">
                        {answerHistory.filter((a) => a.isCorrect).length} / {questions.length}
                      </div>
                    </div>
                    <div className="bg-white/5 p-2 rounded-lg">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Accuracy</div>
                      <div className="font-heading font-bold text-sm text-white">
                        {Math.round((answerHistory.filter((a) => a.isCorrect).length / Math.max(1, questions.length)) * 100)}%
                      </div>
                    </div>
                    <div className="bg-white/5 p-2 rounded-lg">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Max Streak</div>
                      <div className="font-heading font-bold text-sm text-amber-400">{maxStreak}x</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setIsChallengeOpen(true)}
                  className="bg-[#38bdf8] hover:bg-[#38bdf8]/90 text-[#03131e] font-heading font-black text-xs uppercase px-5 py-3 rounded-xl flex items-center gap-1.5 shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Challenge Friends</span>
                </button>

                <button
                  onClick={() => {
                    if (isIQTestMode) startFootballIQTest();
                    else launchQuizSession(questions, selectedTier);
                  }}
                  className="bg-[#00ff88] hover:bg-white text-[#07100c] font-heading font-black text-xs uppercase px-5 py-3 rounded-xl flex items-center gap-1.5 shadow-[0_0_20px_rgba(0,255,136,0.4)] transition-all"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Test</span>
                </button>

                <button
                  onClick={() => setCurrentView('menu')}
                  className="bg-white/10 hover:bg-white/20 text-white font-heading font-bold text-xs uppercase px-5 py-3 rounded-xl flex items-center gap-1.5 border border-white/20 transition-all"
                >
                  <Home className="w-4 h-4" />
                  <span>Main Menu</span>
                </button>
              </div>

              {/* 300x250 Banner in Summary view */}
              <BannerAd300x250 className="pt-2" />
            </div>
          )}

          {/* Ad Slot 1: Global Banner / Native Container Code */}
          <NativeAdContainer className="mt-5 pt-3 border-t border-white/10" />
        </div>
      </main>

      {/* Professional 4-Column Footer */}
      <footer className="bg-[#050c09]/95 border-t border-[#00ff88]/20 mt-8 py-8 px-4 text-xs text-slate-400">
        <div className="max-w-5xl mx-auto space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div>
              <div className="font-heading font-black text-white text-base tracking-wider uppercase">
                ULTIMATE <span className="text-[#00ff88]">FOOTBALL ARENA</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                The international benchmark for tactical acumen, football heritage, and trivia mastery.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-white/5 border border-white/10 px-2.5 py-1 rounded-md text-[10px] font-bold text-slate-300">
                🏛️ UEFA Academy Standards
              </span>
              <span className="bg-[#00ff88]/15 border border-[#00ff88]/30 px-2.5 py-1 rounded-md text-[10px] font-bold text-[#00ff88]">
                100% Free Public Tool
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-xs">
            <div>
              <h4 className="font-heading font-bold text-white uppercase text-xs tracking-wider mb-2 text-[#00ff88]">
                🛡️ Who We Are
              </h4>
              <p className="leading-relaxed text-slate-400 text-[11px]">
                Founded by sports data tacticians and lifelong football historians to calibrate genuine football memory and tactical pattern recognition.
              </p>
            </div>

            <div>
              <h4 className="font-heading font-bold text-white uppercase text-xs tracking-wider mb-2 text-[#38bdf8]">
                📐 Methodology
              </h4>
              <ul className="space-y-1.5 text-[11px]">
                <li><button onClick={() => setIsFAQOpen(true)} className="hover:text-white text-left">The 70–160 IQ Scale ➔</button></li>
                <li><button onClick={() => setIsFAQOpen(true)} className="hover:text-white text-left">Brain Age Formula ➔</button></li>
                <li><button onClick={() => setIsFAQOpen(true)} className="hover:text-white text-left">Linguistic Fuzzy Input ➔</button></li>
              </ul>
            </div>

            <div>
              <h4 className="font-heading font-bold text-white uppercase text-xs tracking-wider mb-2 text-[#f59e0b]">
                ❓ Help &amp; Desk
              </h4>
              <ul className="space-y-1.5 text-[11px]">
                <li><button onClick={() => setIsFAQOpen(true)} className="hover:text-white text-left">Frequently Asked Questions ➔</button></li>
                <li><button onClick={() => setIsContactOpen(true)} className="hover:text-white text-left">Suggest a Match Fact ➔</button></li>
                <li><button onClick={() => setIsContactOpen(true)} className="hover:text-white text-left">Contact Editorial Board ➔</button></li>
              </ul>
            </div>

            <div>
              <h4 className="font-heading font-bold text-white uppercase text-xs tracking-wider mb-2 text-slate-300">
                ⚖️ Legal &amp; Privacy
              </h4>
              <ul className="space-y-1.5 text-[11px]">
                <li><button onClick={() => setIsPrivacyOpen(true)} className="hover:text-[#38bdf8] text-left">Privacy Policy (GDPR/CCPA) ➔</button></li>
                <li><button onClick={() => setIsTermsOpen(true)} className="hover:text-white text-left">Terms of Service ➔</button></li>
                <li><button onClick={handleResetData} className="text-red-400 hover:text-red-300 text-left">Reset My Stored Arena Data ➔</button></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/5 pt-4 text-[10px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
            <div>
              <strong>Nominative Fair Use:</strong> FIFA, UEFA Champions League, Premier League, Ballon d'Or, and club crests are trademarks of their respective governing entities utilized strictly for historical commentary and trivia.
            </div>
            <div className="font-bold text-slate-400 flex-shrink-0">
              © 2026 Ultimate Football Quiz Arena. All rights reserved.
            </div>
          </div>
        </div>
      </footer>

      {/* Modals & Dialogs */}
      <FAQModal isOpen={isFAQOpen} onClose={() => setIsFAQOpen(false)} />
      <PrivacyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} onResetData={handleResetData} />
      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
      <ContactModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
      <ChallengeModal 
        isOpen={isChallengeOpen} 
        onClose={() => setIsChallengeOpen(false)} 
        score={score} 
        iq={bestIQ || 120} 
        brainAge={iqResult?.brainAge || 28} 
      />

      {/* Cookie & Local Storage Notice Banner */}
      <CookieBanner onOpenPrivacy={() => setIsPrivacyOpen(true)} />
    </div>
  );
}
