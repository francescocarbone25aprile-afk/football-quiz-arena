/**
 * Core Quiz Logic & Validation Utilities
 * Pure functions decoupled from DOM/React for deterministic unit testing.
 */

export interface RankInfo {
  title: string;
  badge: string;
  description: string;
}

export interface IQResult {
  iq: number;
  footballAge: number;
  footballAgeLabel: string;
  smartnessPercent: number;
  tier: string;
  badge: string;
  isBadIQ: boolean;
  verdict: string;
  description: string;
}

/**
 * Remove diacritics/accents, special symbols, and normalize whitespace
 */
export function normalizeString(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove accent marks
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ') // replace punctuation with spaces
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Levenshtein distance calculation for typo tolerance
 */
export function levenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;

  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,      // deletion
        dp[i][j - 1] + 1,      // insertion
        dp[i - 1][j - 1] + cost // substitution
      );
    }
  }

  return dp[m][n];
}

/**
 * Fuzzy string matching for Extreme difficulty
 */
export function fuzzyMatch(
  input: string,
  acceptedAnswers: string[]
): { isCorrect: boolean; matchedAnswer?: string } {
  const normInput = normalizeString(input);
  if (!normInput) return { isCorrect: false };

  for (const rawAccepted of acceptedAnswers) {
    const normAccepted = normalizeString(rawAccepted);
    if (!normAccepted) continue;

    if (normInput === normAccepted) {
      return { isCorrect: true, matchedAnswer: rawAccepted };
    }

    const acceptedTokens = normAccepted.split(' ').filter(t => t.length > 2);
    const inputTokens = normInput.split(' ').filter(t => t.length > 2);

    if (acceptedTokens.includes(normInput)) {
      return { isCorrect: true, matchedAnswer: rawAccepted };
    }

    if (inputTokens.length === 1 && acceptedTokens.some(tok => tok === inputTokens[0])) {
      return { isCorrect: true, matchedAnswer: rawAccepted };
    }

    const maxAllowedDist = normAccepted.length >= 8 ? 2 : normAccepted.length >= 4 ? 1 : 0;
    if (levenshteinDistance(normInput, normAccepted) <= maxAllowedDist) {
      return { isCorrect: true, matchedAnswer: rawAccepted };
    }

    for (const token of acceptedTokens) {
      const tokenMaxDist = token.length >= 7 ? 2 : token.length >= 4 ? 1 : 0;
      if (levenshteinDistance(normInput, token) <= tokenMaxDist) {
        return { isCorrect: true, matchedAnswer: rawAccepted };
      }
    }
  }

  return { isCorrect: false };
}

/**
 * Strict string matching for Impossible difficulty
 */
export function strictMatch(
  input: string,
  acceptedAnswers: string[]
): { isCorrect: boolean; matchedAnswer?: string } {
  const normInput = normalizeString(input);
  if (!normInput) return { isCorrect: false };

  for (const rawAccepted of acceptedAnswers) {
    const normAccepted = normalizeString(rawAccepted);
    if (normInput === normAccepted) {
      return { isCorrect: true, matchedAnswer: rawAccepted };
    }
  }

  return { isCorrect: false };
}

/**
 * Calculate dynamic score with time bonus and streak multiplier
 */
export function calculateScore(
  basePoints: number,
  remainingSeconds: number,
  streak: number
): number {
  let multiplier = 1.0;
  if (streak >= 8) multiplier = 3.0;
  else if (streak >= 5) multiplier = 2.0;
  else if (streak >= 3) multiplier = 1.5;
  else if (streak >= 2) multiplier = 1.2;

  const timeBonus = Math.max(0, Math.round(remainingSeconds * 10));
  const rawScore = (basePoints + timeBonus) * multiplier;
  return Math.round(rawScore);
}

/**
 * Calculate accuracy percentage
 */
export function calculateAccuracy(correct: number, total: number): number {
  if (total <= 0) return 0;
  return Math.round((correct / total) * 100);
}

/**
 * Calculate Football IQ score, Football Brain Age, and Smartness %
 * If bad IQ (< 100), explicitly verdicts: "You should not play football anymore!"
 */
export function calculateFootballIQ(
  correctCount: number,
  totalCount: number,
  averageTimeFractionRemaining: number
): IQResult {
  if (totalCount <= 0) {
    return {
      iq: 70,
      footballAge: 6,
      footballAgeLabel: '6 Years Old (Pee-Wee Playground)',
      smartnessPercent: 10,
      tier: 'Armchair Pundit',
      badge: '🚫🪑',
      isBadIQ: true,
      verdict: 'You should not play football anymore!',
      description: 'You should not play football anymore! Hang up your boots, donate your shin pads, and stick to watching from the sofa.',
    };
  }

  const accuracyRatio = correctCount / totalCount;
  const speedBonus = Math.min(10, Math.round(Math.max(0, averageTimeFractionRemaining) * 10));
  const rawIQ = Math.round(70 + (accuracyRatio * 80) + speedBonus);
  const iq = Math.min(160, Math.max(70, rawIQ));
  const isBadIQ = iq < 100;
  const smartnessPercent = Math.min(100, Math.max(5, Math.round(((iq - 70) / 90) * 100)));

  if (iq >= 145) {
    return {
      iq,
      footballAge: 58,
      footballAgeLabel: '58 Years Old (Guardiola / Sacchi Mastermind)',
      smartnessPercent,
      tier: 'Tactical Grandmaster (Guardiola / Sacchi Tier)',
      badge: '👑🧠',
      isBadIQ: false,
      verdict: 'Born Tactical Genius! Your vision exceeds elite managers.',
      description: 'Visionary football intellect! You foresee tactical masterclasses and obscure trivia with superhuman accuracy.',
    };
  } else if (iq >= 130) {
    return {
      iq,
      footballAge: 42,
      footballAgeLabel: '42 Years Old (Champions League Veteran Tactician)',
      smartnessPercent,
      tier: 'Champions League Mastermind',
      badge: '⭐🎖️',
      isBadIQ: false,
      verdict: 'European Icon! You read football matches like an open blueprint.',
      description: 'Elite European tactician. Encyclopedic memory of finals, transfer records, and high-pressure moments.',
    };
  } else if (iq >= 115) {
    return {
      iq,
      footballAge: 30,
      footballAgeLabel: '30 Years Old (Prime Midfield General)',
      smartnessPercent,
      tier: 'Pro League Veteran & Tactician',
      badge: '⚽🥇',
      isBadIQ: false,
      verdict: 'Pitch General! Command the midfield with authority.',
      description: 'Strong football purist IQ! You analyze the game with sharp insight and historical depth.',
    };
  } else if (iq >= 100) {
    return {
      iq,
      footballAge: 22,
      footballAgeLabel: '22 Years Old (Promising First-Team Prospect)',
      smartnessPercent,
      tier: 'Season Ticket Diehard',
      badge: '🏟️🧣',
      isBadIQ: false,
      verdict: 'Solid Contender! Great tournament knowledge and instincts.',
      description: 'Solid football heritage knowledge! You know mainstream trophies and Ballon d’Or heroes inside out.',
    };
  } else {
    const age = Math.max(5, Math.round(5 + (iq - 70) * 0.3));
    return {
      iq,
      footballAge: age,
      footballAgeLabel: `${age} Years Old (Pee-Wee Playground)`,
      smartnessPercent,
      tier: 'Armchair Pundit (Severe Tactical Deficiency)',
      badge: '🚫🪑',
      isBadIQ: true,
      verdict: 'You should not play football anymore!',
      description: 'You should not play football anymore! Hang up your boots, sell your studs on eBay, donate your shin pads, and stick to watching from the sofa.',
    };
  }
}

/**
 * Determine Rank Title and Badge based on score and accuracy
 */
export function getRankTitle(accuracyPercent: number, totalScore: number, tier: string): RankInfo {
  if (accuracyPercent === 100) {
    return {
      title: "Ballon d'Or Immortality",
      badge: '🏆👑',
      description: 'Flawless perfection! You belong in the football Hall of Fame alongside Pelé, Maradona, and Messi.',
    };
  }
  if (accuracyPercent >= 80) {
    return {
      title: 'Champions League Icon',
      badge: '⭐🎖️',
      description: 'World-class tactical mastermind. Your knowledge rivals top-tier European managers.',
    };
  }
  if (accuracyPercent >= 60) {
    return {
      title: 'First-Team Captain',
      badge: '⚽🥇',
      description: 'Solid performance on the big stage! You read the game with distinction.',
    };
  }
  if (accuracyPercent >= 40) {
    return {
      title: 'Squad Rotation Player',
      badge: '🏃‍♂️🥈',
      description: 'Decent tactical understanding, but a few sloppy turnovers cost you dearly.',
    };
  }
  return {
    title: 'Sunday League Benchwarmer',
    badge: '🧤🪑',
    description: 'Time to hit the training pitch! Study up on match archives and come back stronger.',
  };
}
