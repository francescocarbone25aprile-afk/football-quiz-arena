export function normalizeString(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .trim()
    .replace(/\s+/g, ' ');
}

export function levenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (a[i - 1] === b[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
  }

  return dp[m][n];
}

export function fuzzyMatch(input: string, targetOrTargets: string | string[], maxDistance: number = 2): boolean {
  const normalizedInput = normalizeString(input);
  if (!normalizedInput) return false;

  const targets = Array.isArray(targetOrTargets) ? targetOrTargets : [targetOrTargets];

  for (const target of targets) {
    const normalizedTarget = normalizeString(target);
    if (!normalizedTarget) continue;

    // Direct match
    if (normalizedInput === normalizedTarget) return true;

    // Surnames and tokens
    const targetTokens = normalizedTarget.split(' ');
    const inputTokens = normalizedInput.split(' ');
    const lastTargetToken = targetTokens[targetTokens.length - 1];
    const lastInputToken = inputTokens[inputTokens.length - 1];

    if (normalizedInput === lastTargetToken) return true;
    if (lastInputToken === lastTargetToken && lastTargetToken.length >= 3) return true;

    // Substring match for lengthy names
    if (normalizedTarget.includes(normalizedInput) && normalizedInput.length >= 4) return true;

    // Levenshtein distance check on full string
    if (levenshteinDistance(normalizedInput, normalizedTarget) <= maxDistance) return true;

    // Levenshtein on surname
    if (lastTargetToken.length >= 4 && levenshteinDistance(normalizedInput, lastTargetToken) <= 1) return true;
  }

  return false;
}

export function strictMatch(input: string, targetOrTargets: string | string[]): boolean {
  const normalizedInput = normalizeString(input);
  if (!normalizedInput) return false;

  const targets = Array.isArray(targetOrTargets) ? targetOrTargets : [targetOrTargets];

  for (const target of targets) {
    const normalizedTarget = normalizeString(target);
    if (normalizedInput === normalizedTarget) return true;

    // Allow just the surname if length >= 4
    const tokens = normalizedTarget.split(' ');
    if (tokens.length > 1 && normalizedInput === tokens[tokens.length - 1] && tokens[tokens.length - 1].length >= 4) {
      return true;
    }
  }

  return false;
}
