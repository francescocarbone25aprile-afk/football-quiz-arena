import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeString,
  fuzzyMatch,
  strictMatch,
  calculateScore,
  calculateAccuracy,
  calculateFootballIQ,
  getRankTitle,
} from './quiz-logic';

test('normalizeString strips accents, punctuation, and trims whitespace', () => {
  assert.equal(normalizeString('  Pelé  '), 'pele');
  assert.equal(normalizeString('Andrés Iniesta!'), 'andres iniesta');
  assert.equal(normalizeString('Luka Modrić'), 'luka modric');
  assert.equal(normalizeString('Mario Götze'), 'mario gotze');
});

test('fuzzyMatch accurately identifies correct answers with accents and surnames', () => {
  const gotzeAnswers = ['Mario Götze', 'Mario Gotze', 'Gotze', 'Goetze'];
  assert.equal(fuzzyMatch('Mario Gotze', gotzeAnswers).isCorrect, true);
  assert.equal(fuzzyMatch('mario gotze', gotzeAnswers).isCorrect, true);
  assert.equal(fuzzyMatch('gotze', gotzeAnswers).isCorrect, true);
  assert.equal(fuzzyMatch('Götze', gotzeAnswers).isCorrect, true);
  assert.equal(fuzzyMatch('gotz', gotzeAnswers).isCorrect, true);
  assert.equal(fuzzyMatch('Muller', gotzeAnswers).isCorrect, false);
});

test('strictMatch validates exact accent-insensitive names only', () => {
  const morenoAnswers = ['Byron Moreno', 'Moreno'];
  assert.equal(strictMatch('Byron Moreno', morenoAnswers).isCorrect, true);
  assert.equal(strictMatch('byron moreno', morenoAnswers).isCorrect, true);
  assert.equal(strictMatch('moreno', morenoAnswers).isCorrect, true);
  assert.equal(strictMatch('byron moren', morenoAnswers).isCorrect, false);
  assert.equal(strictMatch('Collina', morenoAnswers).isCorrect, false);
});

test('calculateScore accounts for base points, remaining seconds, and streak multipliers', () => {
  assert.equal(calculateScore(100, 10, 1), 200);
  assert.equal(calculateScore(100, 10, 2), 240);
  assert.equal(calculateScore(200, 15, 3), 525);
  assert.equal(calculateScore(500, 12, 5), 1240);
  assert.equal(calculateScore(750, 8, 8), 2490);
});

test('calculateAccuracy calculates rounded percentage', () => {
  assert.equal(calculateAccuracy(10, 10), 100);
  assert.equal(calculateAccuracy(7, 10), 70);
  assert.equal(calculateAccuracy(1, 3), 33);
  assert.equal(calculateAccuracy(0, 5), 0);
});

test('calculateFootballIQ calculates IQ score, age, smartness and bad IQ warning', () => {
  const genius = calculateFootballIQ(15, 15, 0.8);
  assert.ok(genius.iq >= 145);
  assert.equal(genius.isBadIQ, false);
  assert.equal(genius.footballAge, 58);
  assert.match(genius.footballAgeLabel, /58 Years Old/);
  assert.ok(genius.smartnessPercent >= 90);

  // Bad IQ test (< 100 IQ): must say "You should not play football anymore!"
  const bad = calculateFootballIQ(2, 15, 0.1);
  assert.ok(bad.iq < 100);
  assert.equal(bad.isBadIQ, true);
  assert.equal(bad.verdict, 'You should not play football anymore!');
  assert.match(bad.description, /You should not play football anymore!/);
  assert.ok(bad.footballAge <= 12);
  assert.match(bad.footballAgeLabel, /Pee-Wee Playground/);
});

test('getRankTitle provides proper ranking tiers', () => {
  const legend = getRankTitle(100, 2500, 'easy');
  assert.equal(legend.title, "Ballon d'Or Immortality");

  const icon = getRankTitle(85, 2000, 'hard');
  assert.equal(icon.title, 'Champions League Icon');

  const benchwarmer = getRankTitle(20, 300, 'extreme');
  assert.equal(benchwarmer.title, 'Sunday League Benchwarmer');
});
