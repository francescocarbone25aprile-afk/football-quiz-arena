import { DifficultyTier, Question, SubCategory } from '../types';

export const QUESTION_DATABASE: Record<DifficultyTier, Record<string, Question[]>> = {
  easy: {
    world_cup: [
      {
        id: 'e-wc-1',
        category: 'WORLD CUP HISTORY',
        difficulty: 'easy',
        text: 'Which nation won the 2022 FIFA World Cup held in Qatar?',
        mode: 'mcq',
        options: ['Argentina', 'France', 'Brazil', 'Croatia'],
        correctAnswer: 'Argentina',
        explanation: 'Argentina defeated France 4-2 on penalties following a thrilling 3-3 draw after extra time in Lusail.'
      },
      {
        id: 'e-wc-2',
        category: 'WORLD CUP HISTORY',
        difficulty: 'easy',
        text: 'Which country has won the most FIFA World Cup titles in men’s football history?',
        mode: 'mcq',
        options: ['Brazil', 'Germany', 'Italy', 'Argentina'],
        correctAnswer: 'Brazil',
        explanation: 'Brazil holds the record with 5 World Cup titles (1958, 1962, 1970, 1994, 2002).'
      },
      {
        id: 'e-wc-3',
        category: 'WORLD CUP HISTORY',
        difficulty: 'easy',
        text: 'Who scored the famous "Hand of God" goal at the 1986 World Cup in Mexico?',
        mode: 'mcq',
        options: ['Diego Maradona', 'Pelé', 'Gary Lineker', 'Michel Platini'],
        correctAnswer: 'Diego Maradona',
        explanation: 'Diego Maradona punched the ball past Peter Shilton before scoring the Goal of the Century minutes later.'
      },
      {
        id: 'e-wc-4',
        category: 'WORLD CUP HISTORY',
        difficulty: 'easy',
        text: 'Which country hosted and won the 1998 FIFA World Cup?',
        mode: 'mcq',
        options: ['France', 'Brazil', 'Italy', 'Netherlands'],
        correctAnswer: 'France',
        explanation: 'France defeated Brazil 3-0 in the Stade de France final with two goals from Zinedine Zidane.'
      },
      {
        id: 'e-wc-5',
        category: 'WORLD CUP HISTORY',
        difficulty: 'easy',
        text: 'Who was the all-time leading goalscorer in men’s FIFA World Cup tournament history?',
        mode: 'mcq',
        options: ['Miroslav Klose', 'Ronaldo Nazário', 'Gerd Müller', 'Just Fontaine'],
        correctAnswer: 'Miroslav Klose',
        explanation: 'Germany’s Miroslav Klose scored 16 World Cup finals goals across four tournaments (2002–2014).'
      }
    ],
    transfers: [
      {
        id: 'e-tr-1',
        category: 'TRANSFER RECORDS',
        difficulty: 'easy',
        text: 'Which player holds the world record for the highest transfer fee (€222 million) in 2017?',
        mode: 'mcq',
        options: ['Neymar', 'Kylian Mbappé', 'Cristiano Ronaldo', 'Jack Grealish'],
        correctAnswer: 'Neymar',
        explanation: 'Paris Saint-Germain activated Neymar’s €222 million buyout clause from FC Barcelona in August 2017.'
      },
      {
        id: 'e-tr-2',
        category: 'TRANSFER RECORDS',
        difficulty: 'easy',
        text: 'Cristiano Ronaldo moved from Manchester United to Real Madrid in 2009 for what then-record fee?',
        mode: 'mcq',
        options: ['£80 Million (€94M)', '£65 Million', '£100 Million', '£50 Million'],
        correctAnswer: '£80 Million (€94M)',
        explanation: 'Ronaldo joined Real Madrid in July 2009 for £80m, remaining the world record until 2013.'
      },
      {
        id: 'e-tr-3',
        category: 'TRANSFER RECORDS',
        difficulty: 'easy',
        text: 'From which German club did Erling Haaland transfer to Manchester City in 2022?',
        mode: 'mcq',
        options: ['Borussia Dortmund', 'Bayern Munich', 'RB Leipzig', 'Bayer Leverkusen'],
        correctAnswer: 'Borussia Dortmund',
        explanation: 'Manchester City triggered Haaland’s release clause of €60m from Borussia Dortmund in summer 2022.'
      }
    ]
  },
  medium: {
    champions_league: [
      {
        id: 'm-ucl-1',
        category: 'CHAMPIONS LEAGUE',
        difficulty: 'medium',
        text: 'Which club won three consecutive UEFA Champions League titles from 2016 to 2018 under Zinedine Zidane?',
        mode: 'mcq',
        options: ['Real Madrid', 'Barcelona', 'Bayern Munich', 'Liverpool'],
        correctAnswer: 'Real Madrid',
        explanation: 'Real Madrid defeated Atlético Madrid (2016), Juventus (2017), and Liverpool (2018) for an unprecedented three-peat in the modern era.'
      },
      {
        id: 'm-ucl-2',
        category: 'CHAMPIONS LEAGUE',
        difficulty: 'medium',
        text: 'In the iconic 2005 Champions League final in Istanbul, from what score did Liverpool recover against AC Milan?',
        mode: 'mcq',
        options: ['3-0 down', '2-0 down', '4-1 down', '3-1 down'],
        correctAnswer: '3-0 down',
        explanation: 'Liverpool trailed 3-0 at half-time before scoring three goals in six second-half minutes and triumphing on penalties.'
      },
      {
        id: 'm-ucl-3',
        category: 'CHAMPIONS LEAGUE',
        difficulty: 'medium',
        text: 'Who scored the famous 93rd-minute equalizing header for Real Madrid in the 2014 Champions League final against Atlético Madrid?',
        mode: 'mcq',
        options: ['Sergio Ramos', 'Cristiano Ronaldo', 'Gareth Bale', 'Karim Benzema'],
        correctAnswer: 'Sergio Ramos',
        explanation: 'Sergio Ramos headed home Luka Modrić’s corner in the 92:48 minute to pave the way for "La Décima".'
      },
      {
        id: 'm-ucl-4',
        category: 'CHAMPIONS LEAGUE',
        difficulty: 'medium',
        text: 'Which player holds the record for the most goals in a single UEFA Champions League season (17 goals in 2013-14)?',
        mode: 'mcq',
        options: ['Cristiano Ronaldo', 'Lionel Messi', 'Robert Lewandowski', 'Ruud van Nistelrooy'],
        correctAnswer: 'Cristiano Ronaldo',
        explanation: 'Cristiano Ronaldo struck 17 goals in 11 appearances during Real Madrid’s 2013-14 triumph.'
      }
    ],
    ballon_dor: [
      {
        id: 'm-bd-1',
        category: 'BALLON D’OR ANNALS',
        difficulty: 'medium',
        text: 'Who is the only defender in the 21st century to win the Ballon d’Or (won in 2006)?',
        mode: 'mcq',
        options: ['Fabio Cannavaro', 'Paolo Maldini', 'Roberto Carlos', 'Virgil van Dijk'],
        correctAnswer: 'Fabio Cannavaro',
        explanation: 'Fabio Cannavaro captained Italy to the 2006 World Cup triumph, conceding only two goals all tournament.'
      },
      {
        id: 'm-bd-2',
        category: 'BALLON D’OR ANNALS',
        difficulty: 'medium',
        text: 'In 2018, who broke the decade-long Messi-Ronaldo duopoly by winning the Ballon d’Or?',
        mode: 'mcq',
        options: ['Luka Modrić', 'Antoine Griezmann', 'Kylian Mbappé', 'Neymar'],
        correctAnswer: 'Luka Modrić',
        explanation: 'Luka Modrić won the Champions League with Real Madrid and led Croatia to their historic first World Cup final.'
      }
    ]
  },
  hard: {
    tactics: [
      {
        id: 'h-tac-1',
        category: 'TACTICAL MASTERCLASS',
        difficulty: 'hard',
        text: 'Which legendary manager pioneered "Total Football" (Totaalvoetbal) with Ajax and the Netherlands in the 1970s?',
        mode: 'mcq',
        options: ['Rinus Michels', 'Johan Cruyff', 'Ernst Happel', 'Arrigo Sacchi'],
        correctAnswer: 'Rinus Michels',
        explanation: 'Rinus Michels developed the fluid positional interchange system, later perfected by his star pupil Johan Cruyff.'
      },
      {
        id: 'h-tac-2',
        category: 'TACTICAL MASTERCLASS',
        difficulty: 'hard',
        text: 'Arsenal completed the entire 38-game 2003-04 Premier League season undefeated under Arsène Wenger. What was their final record?',
        mode: 'mcq',
        options: ['26 Wins, 12 Draws, 0 Losses', '28 Wins, 10 Draws, 0 Losses', '24 Wins, 14 Draws, 0 Losses', '30 Wins, 8 Draws, 0 Losses'],
        correctAnswer: '26 Wins, 12 Draws, 0 Losses',
        explanation: 'Arsenal achieved 90 points with 26 wins and 12 draws, earning the golden replica Premier League trophy as "The Invincibles".'
      },
      {
        id: 'h-tac-3',
        category: 'TACTICAL MASTERCLASS',
        difficulty: 'hard',
        text: 'Which coach managed FC Porto to UEFA Champions League glory in 2004 and Inter Milan to the historic Italian treble in 2010?',
        mode: 'mcq',
        options: ['José Mourinho', 'Carlo Ancelotti', 'Guus Hiddink', 'Rafael Benítez'],
        correctAnswer: 'José Mourinho',
        explanation: 'José Mourinho announced himself as the "Special One" after dominating Europe with Porto and Inter Milan.'
      },
      {
        id: 'h-tac-4',
        category: 'TACTICAL MASTERCLASS',
        difficulty: 'hard',
        text: 'In 2012, Lionel Messi scored a record-breaking 91 official goals in a single calendar year, surpassing which German legend’s 1972 record (85 goals)?',
        mode: 'mcq',
        options: ['Gerd Müller', 'Karl-Heinz Rummenigge', 'Uwe Seeler', 'Jupp Heynckes'],
        correctAnswer: 'Gerd Müller',
        explanation: 'Messi struck 79 goals for Barcelona and 12 for Argentina across 69 matches in 2012.'
      }
    ]
  },
  extreme: {
    obscure_records: [
      {
        id: 'x-obs-1',
        category: 'EXTREME TYPING TRIVIA',
        difficulty: 'extreme',
        text: 'Type the surname of the German goalkeeper who came 2nd in the 2002 Ballon d’Or and won the Golden Ball at the 2002 World Cup:',
        mode: 'typing',
        correctAnswer: 'Kahn',
        acceptedAnswers: ['Oliver Kahn', 'Kahn'],
        explanation: 'Oliver Kahn was the first and only goalkeeper in FIFA history to win the World Cup Golden Ball.'
      },
      {
        id: 'x-obs-2',
        category: 'EXTREME TYPING TRIVIA',
        difficulty: 'extreme',
        text: 'Who scored the winning goal in extra time for Spain in the 2010 FIFA World Cup final against the Netherlands? (Surname):',
        mode: 'typing',
        correctAnswer: 'Iniesta',
        acceptedAnswers: ['Andres Iniesta', 'Iniesta'],
        explanation: 'Andrés Iniesta scored in the 116th minute at Soccer City, Johannesburg, revealing a tribute to Dani Jarque.'
      },
      {
        id: 'x-obs-3',
        category: 'EXTREME TYPING TRIVIA',
        difficulty: 'extreme',
        text: 'Which Swedish striker scored a breathtaking 30-yard overhead bicycle kick against England in 2012? (First name or surname):',
        mode: 'typing',
        correctAnswer: 'Ibrahimovic',
        acceptedAnswers: ['Zlatan', 'Zlatan Ibrahimovic', 'Ibrahimovic'],
        explanation: 'Zlatan Ibrahimović scored four goals that night, capped off with his Puskás Award-winning overhead kick.'
      },
      {
        id: 'x-obs-4',
        category: 'EXTREME TYPING TRIVIA',
        difficulty: 'extreme',
        text: 'Type the surname of the French striker who won the Premier League Golden Boot 4 times with Arsenal:',
        mode: 'typing',
        correctAnswer: 'Henry',
        acceptedAnswers: ['Thierry Henry', 'Henry'],
        explanation: 'Thierry Henry won the Premier League Golden Boot in 2001-02, 2003-04, 2004-05, and 2005-06.'
      }
    ]
  },
  impossible: {
    historic_oddities: [
      {
        id: 'i-odd-1',
        category: 'IMPOSSIBLE DRILL',
        difficulty: 'impossible',
        text: 'Who was the only goalkeeper in history to win the Ballon d’Or (won in 1963, nicknamed "The Black Spider")? (Surname):',
        mode: 'typing',
        correctAnswer: 'Yashin',
        acceptedAnswers: ['Lev Yashin', 'Yashin'],
        explanation: 'Soviet legend Lev Yashin saved over 150 penalty kicks in his career and won the 1963 Ballon d’Or.'
      },
      {
        id: 'i-odd-2',
        category: 'IMPOSSIBLE DRILL',
        difficulty: 'impossible',
        text: 'Who holds the record for the most goals in a single FIFA World Cup tournament (13 goals for France in 1958)? (Surname):',
        mode: 'typing',
        correctAnswer: 'Fontaine',
        acceptedAnswers: ['Just Fontaine', 'Fontaine'],
        explanation: 'Just Fontaine scored 13 goals in just six matches at the 1958 tournament in Sweden.'
      },
      {
        id: 'i-odd-3',
        category: 'IMPOSSIBLE DRILL',
        difficulty: 'impossible',
        text: 'Which legendary libero captained West Germany to the 1974 World Cup and later managed them to victory in 1990? (Surname):',
        mode: 'typing',
        correctAnswer: 'Beckenbauer',
        acceptedAnswers: ['Franz Beckenbauer', 'Beckenbauer', 'Der Kaiser'],
        explanation: '"Der Kaiser" Franz Beckenbauer was one of only three men to win the World Cup as both captain and manager.'
      },
      {
        id: 'i-odd-4',
        category: 'IMPOSSIBLE DRILL',
        difficulty: 'impossible',
        text: 'Name the Scottish manager who won 13 Premier League titles and 2 Champions Leagues with Manchester United (Surname):',
        mode: 'typing',
        correctAnswer: 'Ferguson',
        acceptedAnswers: ['Alex Ferguson', 'Ferguson', 'Sir Alex Ferguson'],
        explanation: 'Sir Alex Ferguson retired in 2013 with 38 major trophies at Manchester United, cementing his legacy as the most decorated manager.'
      }
    ]
  }
};

export const SUBCATEGORIES: SubCategory[] = [
  {
    id: 'world_cup',
    title: 'World Cup Legends',
    icon: '🏆',
    desc: 'Iconic moments, Golden Boots, and historic tournament triumphs.',
    tier: 'easy',
    questions: QUESTION_DATABASE.easy.world_cup
  },
  {
    id: 'transfers',
    title: 'Transfer Records',
    icon: '💰',
    desc: 'Blockbuster fees, deadline day deals, and galáctico moves.',
    tier: 'easy',
    questions: QUESTION_DATABASE.easy.transfers
  },
  {
    id: 'champions_league',
    title: 'Champions League Drama',
    icon: '⭐',
    desc: 'European nights, iconic comebacks, and continental dominance.',
    tier: 'medium',
    questions: QUESTION_DATABASE.medium.champions_league
  },
  {
    id: 'ballon_dor',
    title: 'Ballon d’Or Annals',
    icon: '🥇',
    desc: 'The best individual football awards, records, and controversies.',
    tier: 'medium',
    questions: QUESTION_DATABASE.medium.ballon_dor
  },
  {
    id: 'tactics',
    title: 'Tactical Masterclasses',
    icon: '📋',
    desc: 'Total Football, Catenaccio, Gegenpressing, and invincible runs.',
    tier: 'hard',
    questions: QUESTION_DATABASE.hard.tactics
  },
  {
    id: 'obscure_records',
    title: 'Extreme Typing Challenge',
    icon: '⚡',
    desc: 'No multiple choice. Direct keyboard submission under pressure.',
    tier: 'extreme',
    questions: QUESTION_DATABASE.extreme.obscure_records
  },
  {
    id: 'historic_oddities',
    title: 'Impossible Heritage Drill',
    icon: '🔥',
    desc: 'The deepest football records in history. 10-second strict clock.',
    tier: 'impossible',
    questions: QUESTION_DATABASE.impossible.historic_oddities
  }
];

export const TIER_SETTINGS: Record<DifficultyTier, {
  name: string;
  badge: string;
  timer: number;
  basePoints: number;
  mode: 'mcq' | 'typing';
  color: string;
  borderColor: string;
}> = {
  easy: {
    name: 'Easy',
    badge: '🟢 ROOKIE',
    timer: 20,
    basePoints: 100,
    mode: 'mcq',
    color: '#00ff88',
    borderColor: 'border-[#00ff88]/40'
  },
  medium: {
    name: 'Medium',
    badge: '🟡 PRO',
    timer: 15,
    basePoints: 200,
    mode: 'mcq',
    color: '#38bdf8',
    borderColor: 'border-[#38bdf8]/40'
  },
  hard: {
    name: 'Hard',
    badge: '🟠 MASTER',
    timer: 12,
    basePoints: 350,
    mode: 'mcq',
    color: '#f59e0b',
    borderColor: 'border-[#f59e0b]/40'
  },
  extreme: {
    name: 'Extreme',
    badge: '🔴 LEGEND',
    timer: 15,
    basePoints: 550,
    mode: 'typing',
    color: '#ef4444',
    borderColor: 'border-[#ef4444]/40'
  },
  impossible: {
    name: 'Impossible',
    badge: '🟣 GOD TIER',
    timer: 10,
    basePoints: 800,
    mode: 'typing',
    color: '#c084fc',
    borderColor: 'border-[#c084fc]/40'
  }
};

export const FOOTBALL_IQ_QUESTIONS: Question[] = [
  ...QUESTION_DATABASE.easy.world_cup.slice(0, 3),
  ...QUESTION_DATABASE.easy.transfers.slice(0, 2),
  ...QUESTION_DATABASE.medium.champions_league.slice(0, 3),
  ...QUESTION_DATABASE.medium.ballon_dor.slice(0, 2),
  ...QUESTION_DATABASE.hard.tactics.slice(0, 3),
  ...QUESTION_DATABASE.extreme.obscure_records.slice(0, 1),
  ...QUESTION_DATABASE.impossible.historic_oddities.slice(0, 1)
];
