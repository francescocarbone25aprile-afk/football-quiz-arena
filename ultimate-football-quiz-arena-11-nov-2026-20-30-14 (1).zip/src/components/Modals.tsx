import React, { useState } from 'react';
import { X, ChevronDown, Trash2, Send, CheckCircle, Shield, HelpCircle, FileText, Keyboard, Share2 } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FAQModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  if (!isOpen) return null;

  const faqs = [
    {
      q: '1. How is the official 70–160 Football IQ calculated?',
      a: 'The Football IQ test spans 15 questions from basic World Cup records to impossible tactical anomalies. Points are weighted exponentially by difficulty (from 100 to 800 base). Swift answers within the first 3 seconds yield maximum streak multipliers (up to 3.0x). Your cumulative points map to a normalized Gaussian bell curve: average is 100, elite tacticians reach 130+, and tactical grandmasters reach 150+.'
    },
    {
      q: '2. What does the "You should not play football anymore" verdict mean?',
      a: 'If your Football IQ score falls below 100, the arena returns this verdict. It signifies that your tactical instincts, rule comprehension, or match history recall fell below the competitive threshold. It is a playful prompt to hang up your boots, donate your shin pads, and spend time studying tournament archives before taking the pitch again!'
    },
    {
      q: '3. What is "Football Brain Age"?',
      a: 'Your Football Brain Age assesses the depth of your tactical memory independent of biological age. Scores of 145+ reflect a brain age of 55–60 years (veteran continental manager like Sacchi or Ferguson). Low scores return a brain age of 5–8 years (Playground Peewee).'
    },
    {
      q: '4. How does text typing work in Extreme & Impossible tiers?',
      a: 'Extreme and Impossible tiers do not have multiple choice options. You type answers directly. Our linguistic engine strips accents (é, ü, ñ, ç are normalized) and permits minor typographical variances up to a Levenshtein distance of 2. You can type either the player’s iconic surname (e.g. "Beckenbauer", "Iniesta") or full official name.'
    },
    {
      q: '5. Is the Arena 100% free? Are there paywalls?',
      a: 'Yes, 100% free with zero paywalls. Ultimate Football Quiz Arena is an open educational and tactical resource funded strictly through standard non-intrusive display banners. No registration or credit cards are ever required.'
    },
    {
      q: '6. Where is my score and Football IQ data saved?',
      a: 'All data—including your personal best score, Football IQ scorecard, and sound preferences—is stored exclusively in your browser’s private HTML5 localStorage. No personal data is transmitted to external servers.'
    },
    {
      q: '7. Can I play using keyboard shortcuts?',
      a: 'Yes! On desktop, press 1–4 to select Multiple Choice options, Enter/Space to advance, Esc to close modals, and M to toggle sound effects.'
    },
    {
      q: '8. How are historical questions verified for accuracy?',
      a: 'Every prompt is cross-referenced with primary official records from FIFA match reports, UEFA European Cup archives, and the International Federation of Football History & Statistics (IFFHS).'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0b1a13] border-2 border-[#00ff88] rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-[0_0_50px_rgba(0,255,136,0.25)] relative overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-6 h-6 text-[#00ff88]" />
            <h3 className="font-heading text-xl font-bold text-white uppercase tracking-wider">
              Frequently Asked Questions (FAQ)
            </h3>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-3 flex-1 text-slate-300 text-sm">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div 
                key={idx} 
                className={`border rounded-xl transition-all ${isOpen ? 'border-[#00ff88] bg-[#07140e]' : 'border-white/10 bg-black/30'}`}
              >
                <button
                  type="button"
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between p-3.5 text-left font-heading text-white font-semibold text-sm hover:text-[#00ff88] transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-[#00ff88] transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-3.5 pb-3.5 text-slate-300 leading-relaxed text-xs sm:text-sm border-t border-white/5 pt-2">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export const PrivacyModal: React.FC<ModalProps & { onResetData: () => void }> = ({ isOpen, onClose, onResetData }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0b1a13] border-2 border-[#38bdf8] rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-[0_0_50px_rgba(56,189,248,0.25)] relative overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-[#38bdf8]" />
            <h3 className="font-heading text-xl font-bold text-white uppercase tracking-wider">
              Privacy Policy &amp; Data Rights (GDPR/CCPA)
            </h3>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-slate-300 text-xs sm:text-sm leading-relaxed">
          <div className="bg-black/40 border border-white/10 rounded-lg p-3 text-xs text-slate-400 flex items-center gap-2">
            <span className="bg-[#00ff88]/20 text-[#00ff88] font-bold px-2 py-0.5 rounded border border-[#00ff88]/30">GDPR &amp; CCPA</span>
            <span>Client-First • Zero Personal Data Sold • Private Browser Storage</span>
          </div>

          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#38bdf8]">1. Privacy by Design</h4>
            <p>Ultimate Football Quiz Arena does not collect, sell, or rent your personal data. We do not require account registration, passwords, email addresses, or phone numbers.</p>
          </div>

          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#38bdf8]">2. Local Storage Disclosures</h4>
            <p>The application uses your browser's private HTML5 localStorage exclusively to remember your highest score, Football IQ scorecard, and audio mute settings on your device.</p>
          </div>

          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#38bdf8]">3. Web Audio API</h4>
            <p>Sound effects are synthesized dynamically in memory using the browser's Web Audio API. We never access your device microphone or camera.</p>
          </div>

          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#38bdf8]">4. Display Advertising</h4>
            <p>To sustain free access, the arena hosts standard banner display placements. Advertising partners may utilize anonymous identifiers according to standard digital ad regulations.</p>
          </div>

          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mt-4">
            <div className="flex items-center gap-2 text-red-400 font-bold mb-1">
              <Trash2 className="w-4 h-4" />
              <span>Right to Erasure / Reset Stored Data</span>
            </div>
            <p className="text-xs text-slate-300 mb-3">
              Click below to permanently erase your stored High Score and Football IQ record from this browser cache.
            </p>
            <button
              type="button"
              onClick={onResetData}
              className="bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Wipe All My Local Arena Data Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const TermsModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0b1a13] border-2 border-[#f59e0b] rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-[0_0_50px_rgba(245,158,11,0.25)] relative overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-[#f59e0b]" />
            <h3 className="font-heading text-xl font-bold text-white uppercase tracking-wider">
              Terms of Service &amp; Fair Play
            </h3>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-slate-300 text-xs sm:text-sm leading-relaxed">
          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#f59e0b]">1. Educational Fair Use &amp; Trademarks</h4>
            <p>All club names, player trademarks, badges, and tournament names (including FIFA World Cup, UEFA Champions League, Premier League, and Ballon d'Or) belong to their respective owners and are referenced under nominative fair use for historical trivia, identification, and educational commentary.</p>
          </div>

          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#f59e0b]">2. Anti-Cheat &amp; Fair Play</h4>
            <p>Users agree not to deploy automated answering scripts, scrapers, or tamper with countdown timers when taking certified assessments.</p>
          </div>

          <div>
            <h4 className="font-heading font-bold text-white text-base mb-1 text-[#f59e0b]">3. Entertainment Disclaimer</h4>
            <p>The Football IQ test is formulated for sports trivia and tactical education. The humorous verdict stating <em>"You should not play football anymore"</em> is a playful gaming mechanic and not a professional athletic disqualification.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export const ContactModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [category, setCategory] = useState('question');
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    soundManager.playCorrect();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0b1a13] border-2 border-[#00ff88] rounded-2xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-[0_0_50px_rgba(0,255,136,0.25)] relative overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Send className="w-5 h-5 text-[#00ff88]" />
            <h3 className="font-heading text-lg font-bold text-white uppercase tracking-wider">
              Contact Editorial &amp; Submit Questions
            </h3>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto">
          {submitted ? (
            <div className="text-center py-6 space-y-3">
              <CheckCircle className="w-12 h-12 text-[#00ff88] mx-auto animate-bounce" />
              <h4 className="font-heading text-lg font-bold text-white">Dispatched to Tactical Desk</h4>
              <p className="text-xs text-slate-300">
                Thank you! Your submission has been logged under reference <strong>UEFA-DESK-{Math.floor(1000 + Math.random() * 9000)}</strong>. Our historians review submissions regularly.
              </p>
              <button
                type="button"
                onClick={() => { setSubmitted(false); setMessage(''); onClose(); }}
                className="mt-4 bg-[#00ff88] text-[#07100c] font-bold text-xs uppercase px-4 py-2 rounded-lg hover:bg-white transition-colors"
              >
                Close Desk
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-1">Inquiry Type *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-[#07140e] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:border-[#00ff88] outline-none"
                >
                  <option value="question">💡 Suggest a New Trivia Question</option>
                  <option value="correction">⚠️ Report Match Fact Correction</option>
                  <option value="bug">🐛 Technical Bug or Display Issue</option>
                  <option value="partnership">🤝 Licensing &amp; Tournament Partnership</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-1">Your Name / Football Handle (Optional)</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Tactician Marco"
                  className="w-full bg-[#07140e] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:border-[#00ff88] outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-1">Question &amp; Official Source Reference *</label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your question, match date, verified source, or feedback..."
                  className="w-full bg-[#07140e] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:border-[#00ff88] outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#00ff88] text-[#07100c] font-heading font-extrabold uppercase py-2.5 rounded-xl hover:bg-white transition-all shadow-[0_0_20px_rgba(0,255,136,0.3)] text-xs tracking-wider"
              >
                ✉️ Send to Tactical Editorial Board
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export const ChallengeModal: React.FC<ModalProps & { score: number; iq: number; brainAge: number }> = ({ 
  isOpen, 
  onClose, 
  score, 
  iq, 
  brainAge 
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const shareText = `🧠 I scored ${score.toLocaleString()} PTS with an official Football IQ of ${iq} (Brain Age: ${brainAge} yrs) in the Ultimate Football Quiz Arena! Think you can beat me? Take the test now!`;
  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

  const handleCopy = () => {
    navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0b1a13] border-2 border-[#38bdf8] rounded-2xl max-w-md w-full p-5 shadow-[0_0_50px_rgba(56,189,248,0.3)] relative text-center">
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <Share2 className="w-10 h-10 text-[#38bdf8] mx-auto mb-2" />
        <h3 className="font-heading text-xl font-bold text-white uppercase tracking-wider mb-1">
          Challenge Your Friends!
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Share your certified scorecard and see who truly understands football geometry:
        </p>

        <div className="bg-black/50 border border-[#38bdf8]/40 rounded-xl p-3.5 mb-5 text-left space-y-1.5">
          <div className="text-xs font-bold text-[#38bdf8]">🏆 FOOTBALL IQ SCORECARD</div>
          <div className="text-base font-extrabold text-white font-heading">
            IQ: {iq} • BRAIN AGE: {brainAge} YRS
          </div>
          <div className="text-xs text-slate-300">
            Arena Score: <span className="font-bold text-[#00ff88]">{score.toLocaleString()} PTS</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <a
            href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText} ${shareUrl}`)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#25d366] text-[#032d12] font-bold text-xs py-2.5 rounded-xl hover:brightness-110 flex items-center justify-center gap-1.5"
          >
            📱 WhatsApp
          </a>
          <a
            href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#1da1f2] text-white font-bold text-xs py-2.5 rounded-xl hover:brightness-110 flex items-center justify-center gap-1.5"
          >
            🐦 X / Twitter
          </a>
          <button
            onClick={handleCopy}
            className="col-span-2 bg-white/15 hover:bg-white/25 text-white font-bold text-xs py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 border border-white/20"
          >
            {copied ? '✅ Link Copied to Clipboard!' : '📋 Copy Challenge Link'}
          </button>
        </div>
      </div>
    </div>
  );
};
