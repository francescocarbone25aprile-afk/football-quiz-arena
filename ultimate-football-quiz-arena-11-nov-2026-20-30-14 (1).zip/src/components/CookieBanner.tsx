import React, { useState, useEffect } from 'react';

export const CookieBanner: React.FC<{ onOpenPrivacy: () => void }> = ({ onOpenPrivacy }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('football_quiz_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('football_quiz_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#050e0a]/95 border-t border-[#00ff88] backdrop-blur-md py-3 px-4 shadow-[0_-10px_30px_rgba(0,0,0,0.7)] animate-in slide-in-from-bottom duration-300">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-300">
        <div className="flex-1">
          🍪 <strong className="text-[#00ff88]">Privacy &amp; Device Storage:</strong> We use essential local device storage to remember your personal best scores, Football IQ scorecard, and audio preferences. We do not sell your personal data or track you across the web.
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={onOpenPrivacy}
            className="text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-white/10 hover:border-white/30 transition-colors"
          >
            Privacy Policy
          </button>
          <button
            onClick={handleAccept}
            className="bg-[#00ff88] text-[#07100c] font-bold px-4 py-1.5 rounded-lg hover:bg-white transition-colors uppercase font-heading text-xs tracking-wider"
          >
            Accept &amp; Continue
          </button>
        </div>
      </div>
    </div>
  );
};
