import React from 'react';

/**
 * Ad Code 1: Global Banner / Native Container Code
 * Script: <script async="async" data-cfasync="false" src="https://bauval.org/21/0f92a89dc9c6636d518a858ed966d2b0"></script>
 * Container: <div id="container-0f92a89dc9c6636d518a858ed966d2b0"></div>
 */
export const NativeAdContainer: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`w-full max-w-[900px] mx-auto my-3 ${className}`}>
      <div className="flex items-center justify-between text-[10px] tracking-wider uppercase text-slate-500 font-semibold px-2 mb-1">
        <span>Advertisement • Sponsored Partner</span>
        <span>Native Container</span>
      </div>
      <div className="bg-[#0b1a13]/80 border border-[#00ff88]/20 rounded-xl p-2.5 overflow-hidden shadow-lg backdrop-blur-sm">
        <div id="container-0f92a89dc9c6636d518a858ed966d2b0" className="min-h-[60px] flex items-center justify-center text-xs text-slate-400">
          {/* Adsterra/Bauval Native Widget Injects Here */}
          <div className="flex items-center justify-between gap-3 w-full py-1 px-2">
            <div className="flex items-center gap-2">
              <span className="bg-[#00ff88]/20 text-[#00ff88] text-[10px] font-bold px-2 py-0.5 rounded border border-[#00ff88]/40">PRO SPONSOR</span>
              <span className="text-xs text-slate-200 font-medium">Champions League Live Tactical Predictor & Match Center</span>
            </div>
            <a 
              href="#sponsored" 
              className="text-xs bg-[#00ff88] text-[#07100c] font-bold px-3 py-1 rounded-md hover:bg-white transition-colors"
            >
              Explore ➔
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Ad Code 2: 300x250 Banner Ad
 * Placed in sidebar, quiz break, or summary screen
 */
export const BannerAd300x250: React.FC<{ className?: string }> = ({ className = '' }) => {
  const iframeSrcDoc = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { margin: 0; padding: 0; background: transparent; display: flex; justify-content: center; align-items: center; min-height: 250px; }
        </style>
      </head>
      <body>
        <script type="text/javascript">
          atOptions = {
            'key' : '5d3e70412383768e3736b608ca19e4a3',
            'format' : 'iframe',
            'height' : 250,
            'width' : 300,
            'params' : {}
          };
        </script>
        <script type="text/javascript" src="https://bauval.org/22/5d3e70412383768e3736b608ca19e4a3"></script>
      </body>
    </html>
  `;

  return (
    <div className={`flex flex-col items-center justify-center my-4 ${className}`}>
      <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mb-1">
        Sponsored • 300x250 Banner
      </span>
      <div className="w-[300px] h-[250px] bg-[#0b1a13]/90 border border-[#00ff88]/25 rounded-xl overflow-hidden shadow-xl flex items-center justify-center">
        <iframe
          title="Sponsored 300x250 Advertisement"
          width="300"
          height="250"
          className="border-0 w-[300px] h-[250px]"
          scrolling="no"
          srcDoc={iframeSrcDoc}
        />
      </div>
    </div>
  );
};

/**
 * Ad Code 3: 728x90 Leaderboard Banner Ad
 * Placed in main header / top layout wrapper / summary
 */
export const LeaderboardAd728x90: React.FC<{ className?: string }> = ({ className = '' }) => {
  const iframeSrcDoc = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { margin: 0; padding: 0; background: transparent; display: flex; justify-content: center; align-items: center; min-height: 90px; }
        </style>
      </head>
      <body>
        <script type="text/javascript">
          atOptions = {
            'key' : '0e6c803124defb01ad721a104f83874a',
            'format' : 'iframe',
            'height' : 90,
            'width' : 728,
            'params' : {}
          };
        </script>
        <script type="text/javascript" src="https://bauval.org/22/0e6c803124defb01ad721a104f83874a"></script>
      </body>
    </html>
  `;

  return (
    <div className={`w-full max-w-[900px] mx-auto my-3 flex flex-col items-center ${className}`}>
      <div className="w-full flex items-center justify-between text-[10px] tracking-wider uppercase text-slate-500 font-semibold px-2 mb-1">
        <span>Advertisement • Official Sponsor</span>
        <span>Leaderboard 728x90</span>
      </div>
      <div className="w-full max-w-[730px] min-h-[92px] bg-[#0b1a13]/90 border border-[#00ff88]/25 rounded-xl overflow-hidden shadow-xl flex items-center justify-center">
        <div className="w-[728px] max-w-full overflow-x-auto flex justify-center">
          <iframe
            title="Sponsored 728x90 Advertisement"
            width="728"
            height="90"
            className="border-0 max-w-full"
            scrolling="no"
            srcDoc={iframeSrcDoc}
          />
        </div>
      </div>
    </div>
  );
};
