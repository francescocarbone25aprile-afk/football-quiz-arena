export type DifficultyTier = 'easy' | 'medium' | 'hard' | 'extreme' | 'impossible';

export interface Question {
  id: string;
  category: string;
  difficulty: DifficultyTier;
  text: string;
  mode: 'mcq' | 'typing';
  options?: string[];
  correctAnswer: string;
  acceptedAnswers?: string[];
  explanation: string;
}

export interface SubCategory {
  id: string;
  title: string;
  icon: string;
  desc: string;
  tier: DifficultyTier;
  questions: Question[];
}

export interface IQResult {
  iqScore: number;
  brainAge: number;
  smartness: number;
  rankTitle: string;
  isBadIQ: boolean;
  verdict: string;
}

export interface AnswerRecord {
  questionId: string;
  questionText: string;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  pointsEarned: number;
  timeSpent: number;
}
